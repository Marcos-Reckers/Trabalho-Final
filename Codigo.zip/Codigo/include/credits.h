#ifndef credits_H_
#define credits_H_

#include "settings.h"

void credits(cfg *settings);
#endif