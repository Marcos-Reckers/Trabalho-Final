#ifndef movePlayer_H_
#define movePlayer_H_

#include "settings.h"

void movePlayer(cfg *settings);
#endif