#ifndef highscores_H_
#define highscores_H_

#include "settings.h"

void highscores(cfg *settings);

#endif