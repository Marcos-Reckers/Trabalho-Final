#ifndef collision_H_
#define collision_H_

#include "settings.h"

void collision(cfg *settings);

#endif