#ifndef moveEnemy_H_
#define moveEnemy_H_

#include "settings.h"

void moveEnemy(cfg *settings);

#endif