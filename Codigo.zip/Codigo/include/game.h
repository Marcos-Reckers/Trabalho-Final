#ifndef game_H_
#define game_H_

#include "settings.h"

void game(cfg *settings);

#endif