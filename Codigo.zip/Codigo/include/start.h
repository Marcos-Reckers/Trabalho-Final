#ifndef start_H_
#define start_H_

#include "settings.h"

void start(cfg *settings);
#endif