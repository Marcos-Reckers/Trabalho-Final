#ifndef drawMap_H_
#define drawMap_H_

#include "settings.h"

void drawMap(cfg *settings);

#endif