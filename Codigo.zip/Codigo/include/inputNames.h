#ifndef inputNames_H_
#define inputNames_H_

#include "settings.h"

void inputNames(cfg *settings);

#endif