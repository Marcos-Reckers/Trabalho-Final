#ifndef energyCell_H_
#define energyCell_H_

#include "settings.h"

void energyCell(cfg *settings);

#endif