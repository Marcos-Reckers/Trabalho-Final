#ifndef drawPlayer_H_
#define drawPlayer_H_

#include "settings.h"

void drawPlayer(cfg *settings);
#endif