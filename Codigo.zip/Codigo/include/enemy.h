#ifndef enemy_H_
#define enemy_H_

#include "settings.h"

void spawnEnemy(cfg *settings);

void drawEnemy(cfg *settings);
#endif