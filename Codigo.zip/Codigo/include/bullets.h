#ifndef bullets_H_
#define bullets_H_

#include "settings.h"

void bullets(cfg *settings);

#endif