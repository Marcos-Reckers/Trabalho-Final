#ifndef header_H_
#define header_H_

#include "settings.h"

void header(cfg *settings);

#endif