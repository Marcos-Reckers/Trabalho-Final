#ifndef load_H_
#define load_H_

#include "settings.h"

void load(cfg *settings);

#endif