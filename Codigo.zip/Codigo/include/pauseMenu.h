#ifndef pauseMenu_H_
#define pauseMenu_H_

#include "settings.h"

void pauseMenu(cfg *settings);
#endif